# CookbotSitChest BUGFIX — 2026-09-27 (Europe/Istanbul)

**Scope:** Box package only. **Do NOT deploy** until user confirms game closed (`oyun kapalı`).  
**File:** `CookbotSitChest-VAULT-1.0.0/Survival/Scripts/game/interactables/Cookbot.lua`  
**Old MD5:** `a20b211f8e29fd76771a73ac89213e79` (buggy live = Vortex = Survival overwrite)  
**New MD5:** `84d99b4622b4cd72bd378626bd135420`  
**Crafter / ItemPump / ItemFilter:** untouched.

---

## Root causes

### 1) UI shows `0/N` while chest has items
- `cl_onFoodButtonClicked` bound MaterialGrid to **player inventory only**.
- Also called `self:sv_getUnderChestContainer()` from the **client** UI path (wrong realm; often nil).
- Server spend from under-chest still worked → mismatch between UI counts and actual craft.

### 2) Finished food stays with Collect (no auto-deposit)
- `sv_getContainerShapeForRecipe` could refuse under-chest on a bad/false `canCollect` pre-check → `containerObj == nil` → **`batched=true`**.
- With `batched=true`, `Crafter.server_onFixedUpdate` never auto-deposits (Collect path only).
- Cookbot `cl_drawProcess` also omitted Craftbot’s `if not val.batched then remainingTicks = max(..., 1)` so Collect stayed visible even when auto-deposit should own the slot.

### 3) Unlimited burgers / Collect never clears — **critical exploit**
- Overlay `sv_n_collect` called `sv_awardBlockCraftAchievement(...)`.
- In `Crafter.lua` that symbol is a **`local function`** — **not visible** to the Cookbot overlay chunk.
- Sequence: `endTransaction()` **already gave the food** → call to missing global **errors** → `table.remove` / loop-reset **never runs** → slot stays finished → Collect again → free item forever.

---

## What changed (Cookbot.lua only)

| Fix | Change |
|-----|--------|
| UI counts | `cl_getUnderChestContainer` + `cl_bindMaterialContainers` (under-chest + player). No `sv_*` from client. |
| Auto-deposit | Prefer under-chest Shape when container exists; `canCollect` false-negative → optimistic allow; transaction is gate. |
| Collect hide | `cl_drawProcess` matches Craftbot: hide Collect when `not batched` or `count < 1`. |
| Infinite Collect | Inline `awardBlockCraftAchievement` (safe local). On successful Collect: **always** `table.remove` the slot; turn off stuck `loop` + remove automated task. |
| Spend path | `sv_craft` under-chest-first spend kept (minimal diff). |

---

## Residual risks

1. **`setContainers("MaterialGrid", {...})`** — if engine only accepts `""` like Craftbot, single-bind still sets MaterialGrid to under-chest first (counts should leave 0/N). Verify in creative.
2. **Repeat / loop re-spend** still uses inherited `server_onFixedUpdate` pipeGraph inputs only (not Lua under prepend). `-Y` shapeset should expose under-chest to pipeGraph; if snap fails, Repeat won’t keep crafting (safe). Manual Collect no longer leaves a loop zombie.
3. **Survival on Kasa already has buggy overlay** (`A20B211F…`, backup `Cookbot.lua_bak_cookbotsit_20260927`). Deploy replaces it — only when game closed.
4. Food recipes aren’t blocks → achievement helper is a no-op for burgers (same as vanilla intent).

---

## Exact test steps (after user `oyun kapalı` + deploy)

1. Confirm game fully closed; deploy package (Vortex mod +/or Survival file-replace per deploy script).
2. MD5 gate: new Cookbot.lua = `84d99b4622b4cd72bd378626bd135420`. ItemPump/ItemFilter unchanged.
3. Creative: Large Chest under Cookbot; Veggie Burger ingredients **only in chest**; player empty of those.
4. Open Cookbot → ingredient counts must show **chest stock / N** (not `0/N`).
5. Craft once → ingredients leave chest → finished food **auto-lands in under-chest** (no Collect required when space).
6. Fill chest → craft → Collect → food to player (or message if full) → **slot clears**; second Collect does nothing / no free burger.
7. Toggle Repeat with pipe snap: each iteration spends; stop when empty/full. Collect while Repeat on must clear slot (no free loop).
8. Lift Cookbot off chest → vanilla player-inventory fail-safe.
9. Craftbot pipe I/O regression smoke.

---

## Deploy readiness

- Package patched on box: `CookbotSitChest-VAULT-1.0.0/`
- Tarball + `deploy_cookbotsit_bugfix_to_kasa.ps1` prepared.
- **WAIT** for user confirmation: **oyun kapalı** (game closed). Do not push to Vortex/Survival until then.
