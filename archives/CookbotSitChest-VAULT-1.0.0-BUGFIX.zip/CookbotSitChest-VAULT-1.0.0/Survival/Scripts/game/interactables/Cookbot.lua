-- CookbotSitChest-VAULT-1.0.0 (Hybrid A'+B) — BUGFIX pass
-- Overlay only. Does NOT edit Crafter.lua / ItemPump / ItemFilter / Sortbot.
-- Sit-on-chest: Lua resolves under-chest (B); shapeset -Y openings (A') help pipeGraph/Repeat.
-- Spend from under-chest first; deposit food back to same chest; fail-safe = vanilla player inventory.
--
-- BUGFIX (2026-09-27):
-- 1) UI 0/N: MaterialGrid bound to under-chest + player (client-safe resolve). Never call sv_* from client.
-- 2) Auto-deposit: always prefer under-chest Shape so batched=false; fixed-update deposit path runs.
-- 3) Infinite Collect: cl_drawProcess hides Collect when not batched (match Craftbot); Collect always
--    clears finished slot; loop reset cannot re-grant without re-spend.
dofile "$SURVIVAL_DATA/Scripts/game/interactables/Crafter.lua"

local nameToIdx = {}
nameToIdx["Pizza"]   = 1
nameToIdx["Veggie"]  = 2
nameToIdx["Revival"] = 3

Cookbot = class( Crafter )

--------------------------------------------------------------------
-- Under-chest helpers (local -Y / -up neighbor with a storage container)
-- Proven APIs: body:getShapes (PackerPumpArea), raycast (Vacuum), getContainer(0) (Chest).
-- Optional getNeighbours / getPipedNeighbours used only if present.
-- Same helpers are safe on client and server (shape geometry + getContainer).
--------------------------------------------------------------------

local UNDER_MAX_ALONG = 4.0
local UNDER_MAX_LATERAL = 2.0

local function getShapeStorageContainer( shape )
	if not shape or not sm.exists( shape ) then
		return nil
	end
	local interactable = shape:getInteractable()
	if not interactable or not sm.exists( interactable ) then
		return nil
	end
	-- Prefer indexed container (Chest); fall back to no-arg (Crafter auto-deposit style).
	local container = interactable:getContainer( 0 )
	if ( not container or not sm.exists( container ) ) and interactable.getContainer then
		container = interactable:getContainer()
	end
	if container and sm.exists( container ) then
		return container
	end
	return nil
end

local function shapeHasContainer( shape )
	return getShapeStorageContainer( shape ) ~= nil
end

local function isUnderNeighbor( selfShape, otherShape )
	local myPos = selfShape:getWorldPosition()
	local otherPos = otherShape:getWorldPosition()
	local down = -selfShape:getUp()
	local delta = otherPos - myPos
	local along = delta:dot( down )
	if along < 0.05 or along > UNDER_MAX_ALONG then
		return false, along
	end
	local lateral = ( delta - down * along ):length()
	if lateral > UNDER_MAX_LATERAL then
		return false, along
	end
	return true, along
end

--- Shared resolve (client + server). Prefer shape directly under Cookbot.
local function resolveUnderChestShape( selfShape )
	if not selfShape or not sm.exists( selfShape ) then
		return nil
	end

	local bestShape = nil
	local bestAlong = UNDER_MAX_ALONG + 1

	-- 1) Same-body welded neighbours (typical sticky stack)
	local body = selfShape:getBody()
	if body and sm.exists( body ) then
		for _, other in ipairs( body:getShapes() ) do
			if other ~= selfShape and sm.exists( other ) and shapeHasContainer( other ) then
				local ok, along = isUnderNeighbor( selfShape, other )
				if ok and along < bestAlong then
					bestAlong = along
					bestShape = other
				end
			end
		end
	end
	if bestShape then
		return bestShape
	end

	-- 2) Short raycast along local -up (adjacent-body stacks)
	local start = selfShape:getWorldPosition()
	local stop = start - selfShape:getUp() * UNDER_MAX_ALONG
	local hit, result = sm.physics.raycast( start, stop, selfShape )
	if hit and result and result.type == "body" then
		local other = result:getShape()
		if other and other ~= selfShape and sm.exists( other ) and shapeHasContainer( other ) then
			return other
		end
	end

	-- 3) Optional engine neighbour helpers (if present)
	if selfShape.getNeighbours then
		for _, other in ipairs( selfShape:getNeighbours() or {} ) do
			if other and sm.exists( other ) and other ~= selfShape and shapeHasContainer( other ) then
				local ok, along = isUnderNeighbor( selfShape, other )
				if ok and along < bestAlong then
					bestAlong = along
					bestShape = other
				end
			end
		end
	end
	if bestShape then
		return bestShape
	end

	-- 4) Piped neighbours (shapeset -Y openings facing chest +Y) — only if geometrically under
	if selfShape.getPipedNeighbours then
		for _, other in ipairs( selfShape:getPipedNeighbours() or {} ) do
			if other and sm.exists( other ) and shapeHasContainer( other ) then
				local ok = isUnderNeighbor( selfShape, other )
				if ok then
					return other
				end
			end
		end
	end

	return nil
end

local function containerCanHold( container, uid, quantity )
	if not container or not sm.exists( container ) then
		return false
	end
	-- Dual API: static sm.container.canCollect (pipes.lua) and instance :canCollect (Vacuum).
	if sm.container.canCollect then
		local ok = sm.container.canCollect( container, uid, quantity )
		if ok == false then
			return false
		end
		if ok == true then
			return true
		end
	end
	if container.canCollect then
		local ok = container:canCollect( uid, quantity )
		if ok == false then
			return false
		end
		if ok == true then
			return true
		end
	end
	-- API missing / unknown → optimistic; fixed-update / Collect transaction is the real gate.
	return true
end

function Cookbot.sv_getUnderChestShape( self )
	return resolveUnderChestShape( self.shape )
end

function Cookbot.sv_getUnderChestContainer( self )
	local chestShape = resolveUnderChestShape( self.shape )
	if not chestShape then
		return nil, nil
	end
	local container = getShapeStorageContainer( chestShape )
	if container then
		return container, chestShape
	end
	return nil, nil
end

--- Client-safe twin of sv_getUnderChestContainer (shape APIs work on client).
function Cookbot.cl_getUnderChestShape( self )
	return resolveUnderChestShape( self.shape )
end

function Cookbot.cl_getUnderChestContainer( self )
	local chestShape = resolveUnderChestShape( self.shape )
	if not chestShape then
		return nil, nil
	end
	local container = getShapeStorageContainer( chestShape )
	if container then
		return container, chestShape
	end
	return nil, nil
end

local function containerCanAffordRecipe( container, recipe )
	if not container or not sm.exists( container ) then
		return false
	end
	for _, ingredientData in ipairs( recipe.ingredientList ) do
		if container:canSpend( ingredientData.itemId, ingredientData.quantity ) == false then
			return false
		end
	end
	return true
end

local function canSpendFromUnderThenPlayer( underContainer, playerInventory, recipe )
	if containerCanAffordRecipe( playerInventory, recipe ) then
		return true
	end
	if not underContainer then
		return false
	end
	-- Joint: every ingredient must be coverable by under + player combined.
	for _, ingredientData in ipairs( recipe.ingredientList ) do
		local need = ingredientData.quantity
		local inChest = 0
		for slot = 0, underContainer:getSize() - 1 do
			local item = underContainer:getItem( slot )
			if item and item.uuid and tostring( item.uuid ) == tostring( ingredientData.itemId ) then
				inChest = inChest + ( item.quantity or 0 )
			end
		end
		local remain = need - inChest
		if remain > 0 then
			if not playerInventory or playerInventory:canSpend( ingredientData.itemId, remain ) == false then
				return false
			end
		end
	end
	return true
end

-- Crafter.lua defines sv_awardBlockCraftAchievement as a *local* — invisible to this
-- overlay chunk. Calling the missing global after endTransaction() gave the item then
-- errored BEFORE table.remove → unlimited Collect exploit. Inline a safe copy.
local function awardBlockCraftAchievement( recipe, crafts )
	if not crafts or crafts <= 0 then
		return
	end
	local ok, isBlock = pcall( function()
		return sm.item.isBlock( sm.uuid.new( recipe.itemId ) )
	end )
	if ok and isBlock and sm.achievement and sm.achievement.addi then
		sm.achievement.addi( "e5d918b7-8a8b-459b-b988-9f483a54b527", ( recipe.quantity or 1 ) * crafts )
	end
end

--------------------------------------------------------------------
-- UI
--------------------------------------------------------------------

function Cookbot.cl_setupUI( self )
end

--- Bind MaterialGrid ingredient counting to under-chest + player (Craftbot-style multi-container).
function Cookbot.cl_bindMaterialContainers( self )
	local containers = {}
	local underContainer = self:cl_getUnderChestContainer()
	if underContainer then
		containers[#containers + 1] = underContainer
	end
	local playerInventory = sm.localPlayer.getInventory()
	if playerInventory then
		containers[#containers + 1] = playerInventory
	end
	if #containers == 0 then
		return
	end
	-- Craftbot uses setContainers("", {...}). Cookbot MaterialGrid is a named ItemBox —
	-- try named multi-bind first, then "" multi-bind, then single setContainer fallback.
	if #containers > 1 and self.cl.guiInterface.setContainers then
		local ok = pcall( function()
			self.cl.guiInterface:setContainers( "MaterialGrid", containers )
		end )
		if not ok then
			pcall( function()
				self.cl.guiInterface:setContainers( "", containers )
			end )
		end
		-- Also set primary MaterialGrid to under (or player) so single-bind widgets still work.
		self.cl.guiInterface:setContainer( "MaterialGrid", containers[1] )
	else
		self.cl.guiInterface:setContainer( "MaterialGrid", containers[1] )
	end
end

function Cookbot.client_onInteract( self, character, state )
	if state ~= true then
		return
	end

	self.cl.guiInterface = sm.gui.createGuiFromLayout(
		"$GAME_DATA/Gui/Layouts/Interactable/Interactable_CookBot.layout" )

	self.cl.guiInterface:setButtonCallback( "Pizza", "cl_onFoodButtonClicked" )
	self.cl.guiInterface:setButtonCallback( "Veggie", "cl_onFoodButtonClicked" )
	self.cl.guiInterface:setButtonCallback( "Revival", "cl_onFoodButtonClicked" )
	self.cl.guiInterface:setButtonCallback( "Craft", "cl_onCraft" )
	self.cl.guiInterface:setOnCloseCallback( "cl_onClose" )

	local matGrid = {
		type = "materialGrid",
		layout = "$GAME_DATA/Gui/Layouts/Interactable/Interactable_CraftBot_IngredientItem.layout",
		itemWidth = 44,
		itemHeight = 60,
		itemCount = 4,
	}

	self.cl.guiInterface:createGridFromJson( "MaterialGrid", matGrid )
	self.cl.guiInterface:setText( "SubTitle", self.crafter.subTitle )
	self:cl_createProcessGrid()
	self.cl.guiInterface:open()

	if self.cl.selectedButton then
		self:cl_onFoodButtonClicked( self.cl.selectedButton )
	else
		self:cl_onFoodButtonClicked( "Pizza" )
	end
end

function Cookbot.cl_onFoodButtonClicked( self, buttonName )
	if self.cl.selectedButton then
		self.cl.guiInterface:setButtonState( self.cl.selectedButton, false )
	end
	self.cl.selectedButton = buttonName

	-- Ingredient counting: under-chest + player (never call sv_* from client).
	self:cl_bindMaterialContainers()

	local recipe = self:getRecipeByIndex( nameToIdx[buttonName] )
	local recipeUuid = sm.uuid.new( recipe["itemId"] )

	self.cl.guiInterface:setText( "ItemDescription",
		sm.shape.getShapeDescription( recipeUuid ) )

	self.cl.guiInterface:setText( "ItemName",
		sm.shape.getShapeTitle( recipeUuid ) )

	self.cl.guiInterface:setMeshPreview( "Preview", recipeUuid )

	local craftTime = math.ceil( recipe.craftTime / self.crafter.speed ) * 40
	self.cl.guiInterface:setText( "Time", sm.gui.ticksToTimeString( craftTime ) )
	self.cl.guiInterface:clearGrid( "MaterialGrid" )
	for idx, ingredient in ipairs( recipe["ingredientList"] ) do
		local griditem  = {
			itemId = tostring( ingredient.itemId ),
			quantity = ingredient.quantity,
		}
		self.cl.guiInterface:setGridItem( "MaterialGrid", idx - 1, griditem );
	end

	self.cl.selectedRecipe = recipe;
	self.cl.guiInterface:setButtonState( buttonName, true )

	-- Enable Craft if under-chest and/or player inventory can jointly afford.
	-- Server remains authoritative in sv_craft.
	local playerInventory = sm.localPlayer.getInventory()
	local underContainer = self:cl_getUnderChestContainer()
	local canCraft = canSpendFromUnderThenPlayer( underContainer, playerInventory, recipe )
	self.cl.guiInterface:setButtonEnabled( "Craft", canCraft )
end

function Cookbot.cl_onCraft( self, buttonName )
	if self.cl.selectedButton == nil then
		return
	end
	self.network:sendToServer( "sv_n_craftIndex", { index = nameToIdx[self.cl.selectedButton] } )
end

function Cookbot.cl_createProcessGrid( self )
	local procGrid = {
		type = "processGrid",
		layout = "$GAME_DATA/Gui/Layouts/Interactable/Interactable_CraftBot_ProcessItem.layout",
		itemWidth = 98,
		itemHeight = 116,
		itemCount = self.crafter.slots,
	}
	self.cl.guiInterface:createGridFromJson( "ProcessGrid", procGrid )
	self.cl.guiInterface:setGridButtonCallback( "Collect", "cl_onCollect" )
	-- Craftbot path: ProcessItem layout already has Repeat button
	self.cl.guiInterface:setGridButtonCallback( "Repeat", "cl_onRepeat" )
	self:cl_drawProcess()
end

function Cookbot.cl_drawProcess( self )
	for idx = 1, self.crafter.slots do
		local val = self.cl.craftArray[idx]
		if val then
			local recipe = val.recipe
			local recipeCraftTime = math.ceil( recipe.craftTime / self.crafter.speed ) * 40
			-- Match Craftbot: batched multiplies craft time by stack count.
			if val.batched and val.count and val.count > 0 then
				recipeCraftTime = recipeCraftTime * val.count
			end
			local remainingTicks = recipeCraftTime - clamp( val.time, 0, recipeCraftTime )
			-- CRITICAL (infinite-Collect / auto-deposit): when not batched, hide Collect so
			-- Crafter.server_onFixedUpdate auto-deposit owns the finished craft (same as Craftbot).
			if not val.batched then
				remainingTicks = math.max( remainingTicks, 1 )
			end
			-- If count is 0 (loop waiting for re-spend), never show Collect.
			if not val.count or val.count < 1 then
				remainingTicks = math.max( remainingTicks, 1 )
			end

			local gridItem = {
				itemId = tostring( recipe.itemId ),
				craftTime = recipeCraftTime,
				remainingTicks = remainingTicks,
				locked = false,
				repeating = val.loop and true or false,
			}

			self.cl.guiInterface:setGridItem( "ProcessGrid", idx - 1, gridItem )
			self.cl.guiInterface:setWidgetState( "ProcessBackground", remainingTicks == 0 and sm.gui.widgetStates.normal_checked or sm.gui.widgetStates.normal )

			if remainingTicks == 0 then
				self.cl.guiInterface:playGridEffect( "ProcessGrid", idx - 1, "Gui - CraftingDone", false )
			end
		else
			local gridItem = {
				itemId = "00000000-0000-0000-0000-000000000000",
				craftTime = 0,
				remainingTicks = 0,
				locked = false,
				repeating = false,
			}
			self.cl.guiInterface:setGridItem( "ProcessGrid", idx - 1, gridItem )
			if idx == 1 then
				self.cl.guiInterface:setWidgetState( "ProcessBackground", sm.gui.widgetStates.normal )
			end
		end
	end
end

function Cookbot.cl_onCollect( self, name, index )
	self.cl.guiInterface:playGridEffect( "ProcessGrid", index, "Gui - CraftingDoneCollectButton", true )
	self.network:sendToServer( "sv_n_collect", { slot = index } )
end

function Cookbot.cl_onClose( self )
	if self.cl.guiInterface then
		self.cl.guiInterface:destroy()
		self.cl.guiInterface = nil
	end
end

--------------------------------------------------------------------
-- Server: spend / collect prefer under-chest (Crafter.lua untouched)
--------------------------------------------------------------------

--- Prefer under-chest for auto-dump; fall back to vanilla pipe-graph target.
--- Returning a Shape makes Crafter.server_onFixedUpdate set batched=false and auto-collect.
function Cookbot.sv_getContainerShapeForRecipe( self, recipe )
	local under = self:sv_getUnderChestShape()
	if under then
		local container = getShapeStorageContainer( under )
		if container then
			local uid = sm.uuid.new( recipe.itemId )
			local qty = recipe.quantity or 1
			-- Only refuse under-chest when we can prove it cannot hold. Missing API → allow
			-- (transaction in fixed-update / Collect is authoritative). This fixes false
			-- batched=true when canCollect was checked incorrectly.
			local canHold = containerCanHold( container, uid, qty )
			if canHold and recipe.extras then
				for _, extra in ipairs( recipe.extras ) do
					if not containerCanHold( container, sm.uuid.new( extra.itemId ), extra.quantity ) then
						canHold = false
						break
					end
				end
			end
			if canHold then
				return under
			end
		end
	end
	local items = { sm.uuid.new( recipe.itemId ) }
	local quantities = { recipe.quantity }
	if recipe.extras then
		for _, extra in ipairs( recipe.extras ) do
			items[#items + 1] = sm.uuid.new( extra.itemId )
			quantities[#quantities + 1] = extra.quantity
		end
	end
	return sm.pipeGraph.getContainerShapeToCollectTo( self.shape, items, quantities )
end

--- Spend under-chest first, then pipe inputs, then player inventory (vanilla order with under-chest prepended).
function Cookbot.sv_craft( self, params, player )
	local recipe = params.recipe

	if #self.sv.craftArray >= self.crafter.slots then
		print( "Craft queue full" )
		return
	end

	sm.container.beginTransaction()

	local containerArray = {}
	local inputContainers = {}

	local underContainer, underShape = self:sv_getUnderChestContainer()
	if underShape then
		inputContainers[#inputContainers + 1] = underShape
	end

	local pipeInputs = sm.pipeGraph.getInputContainers( self.shape )
	for _, c in ipairs( pipeInputs ) do
		-- Avoid double-spend if pipe graph already sees under-chest
		if c ~= underShape then
			inputContainers[#inputContainers + 1] = c
		end
	end

	if player then
		inputContainers[#inputContainers + 1] = player:getInventory()
	end

	for _, ingredient in ipairs( recipe.ingredientList ) do
		local consumeCount = ingredient.quantity

		for _, container in ipairs( inputContainers ) do
			if consumeCount > 0 then
				local target = nil
				if type( container ) == "Shape" then
					target = getShapeStorageContainer( container )
					if not target and GetPipeGraphObjectContainer then
						target = GetPipeGraphObjectContainer( container )
					end
					if target then
						table.insert( containerArray, { targetContainer = container, itemId = ingredient.itemId } )
					end
				else
					target = container
				end
				if target then
					consumeCount = consumeCount - sm.container.spend( target, ingredient.itemId, consumeCount, false )
				end
			else
				break
			end
		end

		if consumeCount > 0 then
			print( "Could not consume enough of ", ingredient.itemId, " Needed ", consumeCount, " more" )
			sm.container.abortTransaction()
			return
		end
	end

	if sm.container.endTransaction() then
		local containerObj = self:sv_getContainerShapeForRecipe( recipe )
		table.insert( self.sv.craftArray,
			{
				recipe = recipe,
				time = -1,
				loop = params.loop or false,
				count = 1,
				batched = containerObj == nil
			} )

		self:sv_markStorageDirty()
		self:sv_markClientDataDirty()

		if #containerArray > 0 then
			self.network:sendToClients( "cl_n_onCraftFromChest", containerArray )
		end
	else
		print( "Can't afford to craft" )
	end
end

--- Manual Collect: deposit into under-chest when possible; else vanilla player inventory.
--- HARDENING: successful Collect always clears the finished craft (remove). Loop/Repeat does
--- NOT keep a finished collectable slot — that was the unlimited-burger exploit path when
--- loop was stuck or Collect reset without a real re-spend. Repeat continues via auto-deposit
--- (batched=false) in Crafter.server_onFixedUpdate, which re-spends before the next finish.
function Cookbot.sv_n_collect( self, params, player )
	local slotIndex = ( params and params.slot or 0 ) + 1
	local val = self.sv.craftArray[slotIndex]
	if not val then
		return
	end

	local recipe = val.recipe
	if not recipe then
		return
	end

	local count = val.count or 0
	if count < 1 then
		-- Waiting for loop re-spend — nothing to collect. Clear zombie finished UI state.
		if not val.loop then
			table.remove( self.sv.craftArray, slotIndex )
			self:sv_markStorageDirty()
			self:sv_markClientDataDirty()
		end
		return
	end

	local craftTime = math.ceil( recipe.craftTime / self.crafter.speed ) * 40
	if val.batched and count > 0 then
		craftTime = craftTime * count
	end
	if val.time < craftTime then
		print( "Not done" )
		return
	end

	local uid = sm.uuid.new( recipe.itemId )
	local underContainer, underShape = self:sv_getUnderChestContainer()
	local giveQty = ( recipe.quantity or 1 ) * count

	sm.container.beginTransaction()
	local targetInv = nil
	local usedUnder = false
	if underContainer and containerCanHold( underContainer, uid, giveQty ) then
		targetInv = underContainer
		usedUnder = true
	end
	if not targetInv then
		targetInv = player:getInventory()
	end

	sm.container.collect( targetInv, uid, giveQty )
	if recipe.extras then
		for _, extra in ipairs( recipe.extras ) do
			sm.container.collect( targetInv, sm.uuid.new( extra.itemId ), ( extra.quantity or 1 ) * count )
		end
	end

	if sm.container.endTransaction() then
		awardBlockCraftAchievement( recipe, count )

		-- Always clear finished output after a successful Collect.
		-- If Repeat/loop was on, turn it off here: manual Collect means the player took the
		-- item; further iterations must be a new craft (or auto-deposit loop after re-toggling).
		-- This prevents "Collect never clears / unlimited burgers" when loop stuck at count>0.
		if val.loop then
			val.loop = false
			pcall( function()
				sm.pipeGraph.removeAutomatedTask( self.shape, uid )
			end )
		end
		table.remove( self.sv.craftArray, slotIndex )

		self:sv_markStorageDirty()
		self:sv_markClientDataDirty()
		if usedUnder and underShape then
			self.network:sendToClients( "cl_n_onCollectToChest", { targetContainer = underShape, itemId = uid } )
		end
	else
		self.network:sendToClient( player, "cl_n_onMessage", "#{INFO_INVENTORY_FULL}" )
	end
end
