# CookbotSitChest VAULT 1.0.0

**Status:** Packaged on box only — **do not deploy** until user approval.  
**Shape UUID (unchanged):** `2af00456-b22e-4743-b338-a91934aba7c5`  
**Mod UUID:** `a8c3e91f-4d2b-4e6a-9f17-2b5c8d0e6a41`  
**Approach:** Hybrid A' (shapeset `-Y`) + B (Lua under-chest)

## What it does

1. Place **Cookbot on top of a Large Chest** (sticky `-Y`).
2. Craft pulls ingredients **from that under-chest** (then pipe inputs, then player inventory).
3. Finished food auto-collects / Collect deposits **into the same under-chest** (falls back to player if full/missing).
4. **Repeat** wired like Craftbot (`setGridButtonCallback("Repeat","cl_onRepeat")` → inherited `Crafter.sv_n_repeat`). PipeGraph keep-alive needs the `-Y` openings when snap works; Lua still spends/collects via under-chest resolve.

## Files in this package

| Path | Role |
|------|------|
| `Survival/Scripts/game/interactables/Cookbot.lua` | Overlay: under-chest resolve, spend/collect, Repeat UI, canCraft |
| `Survival/Objects/Database/ShapeSets/cookbot.shapeset` | Adds bottom `-Y` input+output pipe openings (Large Chest has `+Y` top) |
| `description.json` / `mod_info.json` / `VAULT_META.json` | Mod identity |

## Explicitly NOT included / NOT modified

- `Crafter.lua`
- `ItemPump.lua` / `ItemFilter.lua`
- Sortbot / ItemSorter
- Recipes (`cookbot.json`)

## Under-chest resolve order (B)

1. Same-body `getShapes()` with geometric under test (`-getUp()`)
2. Short raycast along local `-up`
3. Optional `getNeighbours` / `getPipedNeighbours` if engine exposes them (still under-only)
4. None → vanilla player inventory

## Creative test plan (after future deploy)

1. Backup Survival save.
2. Creative/test world.
3. Large Chest; Pizza ingredients **only** in chest; empty relevant player slots.
4. Cookbot **on top** of the chest.
5. Craft Pizza → ingredients leave chest; food returns to **same** chest.
6. Toggle Repeat; confirm loop while chest has stock / space.
7. Lift Cookbot off chest → player-inventory fail-safe.
8. Craftbot pipe I/O regression gate.
9. MD5: ItemPump `9171E16ADB9E5CFD8A119CF93E47CAA4`; ItemFilter `B8E2E2DB683DFCB05DA08CA50B8927B7`.

## Deploy later (user only)

Vortex file-replace of existing `$SURVIVAL_DATA/.../cookbot.shapeset` and `Cookbot.lua`. Do not duplicate shape UUID. Keep rollback zip.
