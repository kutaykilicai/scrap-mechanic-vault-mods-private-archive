# BUILD — Map Viewer VAULT 1.0.0

Date: 2026-10-04 (Europe/Istanbul). Built on the box. **Not deployed.**

## Why this shape

Official Nexus 52 streams terrain by handlers Mod Manager inserts into `Overworld.lua` (`sv_e_mapViewerLoadCells` and friends). That path was refused. A Vortex folder of the official payload cannot open cells by itself.

This package is a new interactable (`MapViewerVault`, uuid `13c7d07c-9b83-4a53-aabd-9a36bf1e886a`). Press E. No handheld tool, no camera takeover, no cell streaming.

Official zip under `extracted-mapviewer/` was read only for feature limits (bird's-eye, markers, fullscreen). No png, dae, rend, tga, or layout from that zip was copied. Mesh is the vanilla radio renderable.

## Kimi

Runner: `/workspace/moonshot/kimi_swarm.py`.

| Call | Model | Result |
| --- | --- | --- |
| `kimi_mapviewer_job.jsonl` | `kimi-k2.6`, reasoning low, timeout 120s, 2 tries | **TimeoutError** both tries. No review text. `kimi_mapviewer_out.jsonl`. |
| `kimi_mapviewer_job2.jsonl` | `kimi-k3`, reasoning low, timeout 180s | **OK** (content exactly `OK`). 2561 prompt tokens, 409 reasoning tokens. `kimi_mapviewer_out2.jsonl`. |

Before the second call the script was adjusted locally: do not rebuild the GUI on refresh if it exists; `sendToServer` always sends a table; reassign `self.storage.waypoints` after add/remove so the save table is written. Kimi did not request further edits. No terrain or Overworld code was added from either call.

## Overlays that are full files

These four are supersets of the box copy of `ItemPump-VAULT-1.0.0` (pump + sorter lines kept). The ItemPump folder was not written. ItemPump.lua MD5 still `9171e16adb9e5cfd8a119cf93e47caa4`.

- `Survival/Objects/Database/shapesets.json` — plus `mapviewer_vault.shapeset`
- `Survival/Scripts/game/managers/RecipeManager.lua` — plus this uuid in the default unlock list
- `Survival/CraftingRecipes/craftbot/craftbot_small_pipes.json` — plus 5x `8aedf6c2-…` and 1x circuit board `f152e4df-…`
- `Survival/Gui/Language/English/inventoryDescriptions.json` — plus the Map Viewer title

If Vortex lets ItemPump win those paths, the terminal will not be in the shape list or the craft list. Enable this mod so it wins, or merge the one new line back.

Not in the package: `terrain_overworld.lua`, `Overworld.lua`, `SurvivalGame.lua`, `SurvivalPlayer.lua`, Foliage Eraser, Mod Manager, installers.
